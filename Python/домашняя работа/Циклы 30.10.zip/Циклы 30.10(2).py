print("\nЗадача 1")
num = int(input("введите число: "))
count = 0
if num == 0:
        count = 2
else:
    while num > 0:
            num //= 10
            count += 1
    print(count)

summa = 0
count = 0

while True:
    a = input("введите число: ")
    if a == "N":
        break

    num = int(a)
    summa += num
    count += 1

if count > 0:
    print(summa)
    print(summa / count)

  
print("\nЗадача 2")   
n = int(input("Введите размер клетки: "))
str_ = int(input("введите число: "))
stlbc = int(input("введите число: "))

for i in range(str_):
    a = ""              # начинаем пустую строку для строки доски
    for x in range(stlbc):
        if (i + x) % 2 == 0:
            a += "*" * n   # ← добавляем к строке, а не перезаписываем
        else:
            a += "-" * n
    print(a)

print("\nЗадача 3")
for i in range(1, 10):
    for j in range(1, 10):
        print(i * j, end=" ")
    print()